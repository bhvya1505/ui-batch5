import React, { Component }  from 'react';
import ReactDOM from 'react-dom';

/* let elm = React.createElement("ul",null,
    React.createElement("li", null, "List Item 1"),
    React.createElement("li", null, "List Item 2"),
    React.createElement("li", null, "List Item 3")
) */

/* function List(){
    return <ul>
                <li> List Item 1</li>
                <li> List Item 2</li>
                <li> List Item 3</li>
            </ul>
}
 */

class List extends Component{
    render(){
        return <ol>
                    <li> List Item 1 </li>
                    <li> List Item 2 </li>
                    <li> List Item 3 </li>
                </ol>
    }
};

ReactDOM.render(<List/>,document.getElementById("root"));