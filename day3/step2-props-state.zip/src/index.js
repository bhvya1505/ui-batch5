import React, { Component } from 'react';
import ReactDOM from 'react-dom';
// Props
/* 
class Herolist1 extends Component{
    lusticeLeague = ['Batman','Green Lantern', 'Wonder Women', 'Flash', 'Superman', "Cyborg", "Aquaman"]
    render(){
        return <ol>
                    { this.lusticeLeague.map((val, idx)=> <li key={idx}>{ val }</li> ) }
                </ol>
    }
}
class Herolist extends Component{
    avengers = ['Ironman', 'Hulk', 'Captain America', 'Captain Marvel', 'Thor', 'Black Widow']
    render(){
        return <ol>
                    { this.avengers.map((val, idx)=> <li key={idx}>{ val }</li> ) }
                </ol>
    }
} 
*/

class Herolist extends Component{
    state = {
        power : 0
    };
    render(){
        return <div style={ { backgroundColor:'silver', border : "2px dashed silver", margin : "10px", padding : "10px"} }>
                    <h1>{ this.props.title } | version : { this.props.version } | Power : { this.state.power }</h1>
                    <button onClick={ ()=>{
                        this.setState({
                            power : this.state.power + 1
                        })
                    } }>Increase Version</button>
                    <ol>
                        { this.props.heroes.map((val, idx)=> <li key={idx}>{ val }</li> ) }
                    </ol>
                </div>
    }
} 
class MainApp extends Component{
    state = {
    avengers : ['Ironman', 'Hulk', 'Captain America', 'Captain Marvel', 'Thor', 'Black Widow'],
    lusticeLeague : ['Batman','Green Lantern', 'Wonder Women', 'Flash', 'Superman', "Cyborg", "Aquaman"],
    indicHeroes : ['Shaktiman','Chacha Chaoudary','Krish','Hatim','Mighty Raju', 'Chota Bhim']
    }

    render(){
        return <div>
                <h1>Welcome to your life</h1>
                <Herolist version={ 1001 } title="Avengers" heroes={this.state.avengers} />
                <Herolist version={ 1002 } title="Lustice League" heroes={this.state.lusticeLeague} />
                <Herolist version={ 1003 } title="Indic Heroes" heroes={this.state.indicHeroes} />
              </div>
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"))