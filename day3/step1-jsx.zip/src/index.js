import React, { Component } from 'react';
import ReactDOM from 'react-dom';

/*
JSX : JavaScript XML
use className instead of class
use htmlFor instead of for
use inline closing for orphan tags
use camel cased event types
return a single element or one of these
    wrap them in a div 
    React.Fragment 
    <>
*/
class MainApp extends Component{
    render(){
        return<>
                <h1 className="box">Welcome to your life</h1>
                <h1 className="box">Welcome to your life</h1>
                <label htmlFor="uname">User Name : </label>
                <input id="uname" type="text"/>
                <button onClick={()=>{ alert('you clicke the button') }}>Click { 'Hello '+'world' }</button>
              </>
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"))